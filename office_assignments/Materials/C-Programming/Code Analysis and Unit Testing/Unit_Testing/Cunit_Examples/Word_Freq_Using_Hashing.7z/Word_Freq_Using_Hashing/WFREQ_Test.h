/******************************************************************************
* File Name:WFREQ_Test.h
* Purpose: Header file for WFREQ_Test.c
* ARICENT - Copyright (C) 2012 Aricent Inc . All Rights Reserved.
*******************************************************************************/
void WFREQ_myhash_ID_1(void);
void WFREQ_add_inc_word_in_hashtbl_ID_1(void);
void WFREQ_free_hashtable_ID_1(void);
