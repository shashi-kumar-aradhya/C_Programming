/******************************************************************************
* File Name:linked_list_Test.h
* Purpose: Header file for linked_list_Test.c
* ARICENT - Copyright (C) 2012 Aricent Inc . All Rights Reserved.
*******************************************************************************/

void Mylistfunction_create_new_item_ID_1(void);
void  Mylistfunction_add_at_front_ID_1(void);
void  Mylistfunction_add_at_last_ID_1(void);
void  Mylistfunction_lookup_ID_1(void);
void  Mylistfunction_add_at_front_ID_2(void);
void Mylistfunction_create_new_item_ID_2(void);
void Mylistfunction_create_new_item_ID_3(void);
