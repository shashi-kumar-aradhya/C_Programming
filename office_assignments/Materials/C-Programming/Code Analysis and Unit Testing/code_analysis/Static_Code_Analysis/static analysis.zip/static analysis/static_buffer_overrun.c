#include <stdio.h>

int main()
{
   int p_arr[10];
   p_arr[10]=10;
   return 0;
}
